public class Show {
    private boolean plazoF;
    private int tarjetas;    //0,1,2
    private Transaccion [] trans;     //vec de clases 
    private int dimL;
    
    public Show(String alias, int CBU, double dinero,Propietario p,boolean plazoF, int tarjetas){
        super( alias,  CBU,  dinero, p);
        this.plazoF = plazoF;
        this.tarjetas = tarjetas;
        trans = new Transaccion [5];
        for (int i=0;i<5;i++){
            trans[i] = null;
        }
        dimL = 0;
    }
    
    public Show(){
     
    }

    public int getTarjetas() {
        return tarjetas;
    }

    public boolean getPlazoF() {
        return plazoF;
    }

    public void setTarjetas(int tarjetas) {
        this.tarjetas = tarjetas;
    }

    public void setPlazoF(boolean plazoF) {
        this.plazoF = plazoF;
    }
    
    public void agregarTrans(String concepto, double monto) {
         Transaccion t = new Transaccion (concepto,monto);
         trans [dimL] = t;
         dimL++;
    }
    
    public double calcularMonto (){
        double tot = 0;       // aca sumo todo lo que cobra el banco
        double auxD= super.getDinero();
        if (plazoF == true ){
            tot= auxD*0.02;     // le sumo el 2% del dinero
        }
        if (tarjetas ==2){
            tot=auxD+1800;
        }
        else if(tarjetas == 1){
            tot=auxD+1000;
        }
        for (int i=0;i<5;i++){
            if (trans [i].getConcepto().equals("“DEB.CPRA.VTA")){
               double monto= trans [i].getMonto();
               monto += monto * 0.3;      //aumento y despues aumento eso
               monto += monto * 0.35; 
               tot += monto;          //le sumo los impuestos
            }
        }
        return tot;   //retorno el total a cobrar por el banco
    }
    
    public String toString(){
        String aux; 
        aux = "Mi plazoF es " + plazoF + ", mi tarjetas es " + tarjetas ;
        return aux;
    }
        
}
